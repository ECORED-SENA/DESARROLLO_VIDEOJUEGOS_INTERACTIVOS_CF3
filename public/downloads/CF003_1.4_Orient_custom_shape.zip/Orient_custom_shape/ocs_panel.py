import bpy


class BONE_Orient_Custom_Shape_PT_Panel(bpy.types.Panel):
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "bone"
    bl_label = "Orient the custom shape to match the bone"

    @classmethod
    def poll(cls, context):
        if context.edit_bone:
            return True

        ob = context.object
        return ob and ob.mode == 'POSE' and context.bone

    def draw(self, context):
        layout = self.layout
        bone = context.bone
        if not bone:
            bone = context.edit_bone

        row = layout.row()
        row.operator("object.orient_custom_shape", text="Orient Custom Shape", icon='BONE_DATA')