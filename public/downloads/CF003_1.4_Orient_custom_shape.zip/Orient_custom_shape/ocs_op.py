import bpy
from mathutils import *

class BONE_Orient_Custom_Shape_OT_Operator(bpy.types.Operator):
    '''Matches the bone's selected custom shape to the bone's orientation'''
    bl_idname = "object.orient_custom_shape"
    bl_label = "Orient custom shape"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        armatureName = bpy.context.active_object.name
        armature = bpy.data.objects[armatureName]

        activePoseBone = bpy.context.active_pose_bone
        boneName = bpy.context.active_pose_bone.name
        bone = armature.data.bones[boneName]

        objectName = activePoseBone.custom_shape.name
        shapeObject = bpy.data.objects[objectName]

        # Rotate shape object to match bone local rotation in the armature.
        shapeObject.rotation_euler = (0.0, 0.0, 0.0)
        boneChain = bone.parent_recursive
        boneChain.insert(0, bone)

        bone.show_wire = True

        for boneRotation in boneChain:
            rotationMatrix = Matrix((boneRotation.x_axis, boneRotation.y_axis, boneRotation.z_axis)).transposed()
            shapeObject.rotation_euler.rotate(rotationMatrix)

        # Same with translation and scaling.
        shapeObject.location = bone.head_local
        shapeObject.scale = bone.length * Vector((1.0, 1.0, 1.0))

        # Move object to armature coordinates system (except scaling, see below).
        rotationMatrix = armature.rotation_euler
        shapeObject.rotation_euler.rotate(rotationMatrix)
        shapeObject.location.rotate(rotationMatrix)
        shapeObject.location += armature.location

        # Display warning message if the armature has scaling different to one.
        scale = armature.scale

        if(scale.x != 1) or (scale.y != 1) or (scale.z != 1):
            self.report({'Warning'}, "Armature should have a scale factor of 1.0 to match bone shape properly")

        return {'FINISHED'}